package com.ngoconnect.fooddonation.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityLoginBinding
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Ngo
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.model.User
import com.ngoconnect.fooddonation.ngo.NgoHomeActivity

/**
 * Screen 1: Login / Sign Up.
 *
 * Auth is Firebase Authentication (email/password). After a successful
 * sign-in we look the user up in Firestore (`users/{uid}`) to decide where
 * to send them:
 *   - no role yet (brand new sign-up)        -> RoleSelectionActivity
 *   - role already set                       -> DonorHomeActivity / NgoHomeActivity
 *
 * Two "Demo Donor Login" / "Demo NGO Login" buttons let anyone try the app
 * without creating an account by hand: they sign in with a fixed demo
 * email+password, and if that account doesn't exist yet in this Firebase
 * project, it's created on the spot with a role and (for the NGO) a
 * pre-verified location, then straight into the matching dashboard.
 *
 * IMPORTANT (one-time setup in the Firebase console before this will run):
 *   1. Add this app's google-services.json under app/, then uncomment the
 *      com.google.gms.google-services plugin line in app/build.gradle.kts.
 *   2. Authentication -> Sign-in method -> enable Email/Password.
 *   3. Firestore Database -> create a database, then paste firestore.rules
 *      (project root) into Firestore -> Rules.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val auth = FirebaseAuth.getInstance()
    private val repository = FirebaseRepository()
    private var isSignUpMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener { submitForm() }

        binding.signUpPrompt.setOnClickListener {
            isSignUpMode = !isSignUpMode
            binding.loginButton.text = if (isSignUpMode) getString(R.string.sign_up) else getString(R.string.login)
            binding.signUpPrompt.text = if (isSignUpMode) {
                "Already have an account? Log In"
            } else {
                getString(R.string.no_account)
            }
        }

        binding.demoDonorButton.setOnClickListener { demoLogin(isNgo = false) }
        binding.demoNgoButton.setOnClickListener { demoLogin(isNgo = true) }
    }

    override fun onStart() {
        super.onStart()
        // Already signed in from a previous session? Skip straight past login.
        auth.currentUser?.let { routeSignedInUser(it.uid) }
    }

    private fun submitForm() {
        val email = binding.emailInput.text?.toString()?.trim().orEmpty()
        val password = binding.passwordInput.text?.toString().orEmpty()
        if (email.isBlank() || password.isBlank()) {
            Toast.makeText(this, "Enter an email and password", Toast.LENGTH_SHORT).show()
            return
        }
        setLoading(true)
        if (isSignUpMode) {
            auth.createUserWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    result.user ?: return@addOnSuccessListener
                    // No Firestore user doc yet on purpose: routeSignedInUser treats a
                    // missing doc as "needs to pick a role", which is exactly this case.
                    // RoleSelectionActivity writes the real doc (with a role) once chosen.
                    setLoading(false)
                    startActivity(Intent(this, RoleSelectionActivity::class.java))
                    finish()
                }
                .addOnFailureListener { onAuthFailure(it) }
        } else {
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { result ->
                    val uid = result.user?.uid ?: return@addOnSuccessListener
                    routeSignedInUser(uid)
                }
                .addOnFailureListener { onAuthFailure(it) }
        }
    }

    private fun demoLogin(isNgo: Boolean) {
        val email = if (isNgo) DEMO_NGO_EMAIL else DEMO_DONOR_EMAIL
        setLoading(true)
        auth.signInWithEmailAndPassword(email, DEMO_PASSWORD)
            .addOnSuccessListener { result -> routeSignedInUser(result.user!!.uid) }
            .addOnFailureListener { error ->
                if (error is FirebaseAuthInvalidUserException) {
                    provisionDemoAccount(isNgo)
                } else {
                    setLoading(false)
                    Toast.makeText(this, error.message ?: "Demo login failed", Toast.LENGTH_SHORT).show()
                }
            }
    }

    /** First time a demo button is tapped in this Firebase project: create the account + seed data. */
    private fun provisionDemoAccount(isNgo: Boolean) {
        val email = if (isNgo) DEMO_NGO_EMAIL else DEMO_DONOR_EMAIL
        auth.createUserWithEmailAndPassword(email, DEMO_PASSWORD)
            .addOnSuccessListener { result ->
                val uid = result.user!!.uid
                if (isNgo) {
                    val ngo = Ngo(ngoId = uid, name = "Hope Foundation", verified = true, latitude = HYDERABAD_LAT, longitude = HYDERABAD_LNG)
                    repository.saveNgo(ngo) {
                        repository.saveUser(User(userId = uid, name = "Hope Foundation", role = Role.NGO, latitude = HYDERABAD_LAT, longitude = HYDERABAD_LNG)) {
                            setLoading(false)
                            goToNgoHome()
                        }
                    }
                } else {
                    repository.saveUser(User(userId = uid, name = "Green Leaf Restaurant", role = Role.DONOR, latitude = HYDERABAD_LAT, longitude = HYDERABAD_LNG)) {
                        setLoading(false)
                        goToDonorHome()
                    }
                }
            }
            .addOnFailureListener { onAuthFailure(it) }
    }

    private fun routeSignedInUser(uid: String) {
        repository.getUser(uid) { user ->
            setLoading(false)
            when {
                user == null -> {
                    startActivity(Intent(this, RoleSelectionActivity::class.java))
                    finish()
                }
                user.role == Role.NGO -> goToNgoHome()
                else -> goToDonorHome()
            }
        }
    }

    private fun goToDonorHome() {
        startActivity(Intent(this, DonorHomeActivity::class.java))
        finish()
    }

    private fun goToNgoHome() {
        startActivity(Intent(this, NgoHomeActivity::class.java))
        finish()
    }

    private fun onAuthFailure(e: Exception) {
        setLoading(false)
        Toast.makeText(this, e.message ?: getString(R.string.error_generic), Toast.LENGTH_LONG).show()
    }

    private fun setLoading(loading: Boolean) {
        binding.loginButton.isEnabled = !loading
        binding.demoDonorButton.isEnabled = !loading
        binding.demoNgoButton.isEnabled = !loading
        binding.loginButton.text = if (loading) {
            getString(R.string.signing_in)
        } else if (isSignUpMode) {
            getString(R.string.sign_up)
        } else {
            getString(R.string.login)
        }
    }

    companion object {
        const val DEMO_DONOR_EMAIL = "donor.demo@gmail.com"
        const val DEMO_NGO_EMAIL = "ngo.demo@gmail.com"
        const val DEMO_PASSWORD = "Demo@1234"

        // Hyderabad city center -- used so the demo donor/NGO are close enough
        // for the Geo Matching module to produce a realistic "X km away".
        private const val HYDERABAD_LAT = 17.3850
        private const val HYDERABAD_LNG = 78.4867
    }
}
