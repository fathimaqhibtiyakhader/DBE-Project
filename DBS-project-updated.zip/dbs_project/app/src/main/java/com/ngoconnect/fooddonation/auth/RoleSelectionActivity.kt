package com.ngoconnect.fooddonation.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityRoleselectionBinding
import com.ngoconnect.fooddonation.donor.DonorHomeActivity
import com.ngoconnect.fooddonation.model.Ngo
import com.ngoconnect.fooddonation.model.Role
import com.ngoconnect.fooddonation.model.User
import com.ngoconnect.fooddonation.ngo.NgoHomeActivity

/**
 * Shown once, right after sign-up: picks Donor vs NGO and writes the
 * `users/{uid}` doc that everything else (LoginActivity's routing,
 * security rules) keys off of. Choosing NGO also creates a matching
 * `ngos/{uid}` doc with verified=false -- an admin flips that to true in
 * the Firebase console once the org is checked out, which is what makes
 * it eligible for the Geo Matching module.
 */
class RoleSelectionActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRoleselectionBinding
    private val repository = FirebaseRepository()
    private var selectedRole = Role.DONOR

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRoleselectionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        selectCard(Role.DONOR)
        binding.donorCard.setOnClickListener { selectCard(Role.DONOR) }
        binding.ngoCard.setOnClickListener { selectCard(Role.NGO) }

        binding.continueButton.setOnClickListener { saveRoleAndContinue() }
    }

    private fun selectCard(role: Role) {
        selectedRole = role
        binding.donorCard.isSelected = role == Role.DONOR
        binding.ngoCard.isSelected = role == Role.NGO
    }

    private fun saveRoleAndContinue() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val displayName = FirebaseAuth.getInstance().currentUser?.email?.substringBefore("@") ?: "New Member"
        binding.continueButton.isEnabled = false

        when (selectedRole) {
            Role.DONOR -> {
                repository.saveUser(User(userId = uid, name = displayName, role = Role.DONOR)) {
                    startActivity(Intent(this, DonorHomeActivity::class.java))
                    finish()
                }
            }
            Role.NGO -> {
                val ngo = Ngo(ngoId = uid, name = displayName, verified = false)
                repository.saveNgo(ngo) {
                    repository.saveUser(User(userId = uid, name = displayName, role = Role.NGO)) {
                        startActivity(Intent(this, NgoHomeActivity::class.java))
                        finish()
                    }
                }
            }
        }
    }
}
