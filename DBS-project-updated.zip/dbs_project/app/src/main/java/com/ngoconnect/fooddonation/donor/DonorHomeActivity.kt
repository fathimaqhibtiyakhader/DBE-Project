package com.ngoconnect.fooddonation.donor

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityDonorHomeBinding
import com.ngoconnect.fooddonation.impact.ImpactDashboardActivity
import com.ngoconnect.fooddonation.status.DonationStatusActivity

/**
 * Screen 2: Donor Home - welcome, active donations list, + Donate Food action.
 */
class DonorHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDonorHomeBinding
    private lateinit var adapter: DonationAdapter
    private val repository = FirebaseRepository()
    private var donationsListener: ListenerRegistration? = null

    // TODO: replace with the signed-in user's id once LoginActivity exists.
    // FirebaseAuth.currentUser is null until then, so this falls back to a
    // fixed demo id — swap DEMO_DONOR_ID for FirebaseAuth.getInstance().currentUser!!.uid.
    private val donorId: String
        get() = FirebaseAuth.getInstance().currentUser?.uid ?: DEMO_DONOR_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonorHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository.getUser(donorId) { user ->
            binding.donorName.text = user?.name ?: "Donor"
        }

        binding.signOutLink.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, com.ngoconnect.fooddonation.auth.LoginActivity::class.java))
            finish()
        }

        adapter = DonationAdapter(emptyList()) { donation ->
            startActivity(
                Intent(this, DonationStatusActivity::class.java)
                    .putExtra(DonationStatusActivity.EXTRA_DONATION_ID, donation.donationId)
            )
        }
        binding.donationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.donationsRecyclerView.adapter = adapter

        binding.donateFoodFab.setOnClickListener {
            startActivity(Intent(this, CreateDonationActivity::class.java))
        }
        binding.viewImpactLink.setOnClickListener {
            startActivity(Intent(this, ImpactDashboardActivity::class.java))
        }
    }

    override fun onStart() {
        super.onStart()
        donationsListener = repository.listenToDonorDonations(donorId) { donations ->
            adapter.submitList(donations)
            binding.emptyState.visibility = if (donations.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    override fun onStop() {
        super.onStop()
        donationsListener?.remove()
        donationsListener = null
    }

    companion object {
        const val DEMO_DONOR_ID = "demo-donor"
    }
}