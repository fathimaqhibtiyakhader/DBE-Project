package com.ngoconnect.fooddonation.ngo

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ngoconnect.fooddonation.databinding.ItemNgoDonationBinding
import com.ngoconnect.fooddonation.model.Donation

class NgoDonationAdapter(
    private var items: List<Donation>,
    private val onAccept: (Donation) -> Unit
) : RecyclerView.Adapter<NgoDonationAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemNgoDonationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemNgoDonationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val donation = items[position]
        with(holder.binding) {
            foodType.text = donation.foodType
            quantity.text = donation.quantity
            pickupInfo.text = "${donation.pickupDate}, ${donation.pickupTime} · ${donation.pickupLocation}"
            distanceAway.text = "%.1f km away".format(donation.distanceKm)
            acceptButton.setOnClickListener { onAccept(donation) }
        }
    }

    override fun getItemCount(): Int = items.size

    fun submitList(newItems: List<Donation>) {
        items = newItems
        notifyDataSetChanged()
    }
}
