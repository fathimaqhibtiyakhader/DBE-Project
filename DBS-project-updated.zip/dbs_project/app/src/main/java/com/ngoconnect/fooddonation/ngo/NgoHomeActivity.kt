package com.ngoconnect.fooddonation.ngo

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.ListenerRegistration
import com.ngoconnect.fooddonation.R
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityNgoHomeBinding
import com.ngoconnect.fooddonation.model.DonationStatus

/**
 * NGO's home screen: every donation the Geo Matching module has assigned
 * to this NGO and that's waiting to be accepted. Accepting moves it into
 * Pickup Scheduled using the date/time the donor already chose.
 */
class NgoHomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityNgoHomeBinding
    private lateinit var adapter: NgoDonationAdapter
    private val repository = FirebaseRepository()
    private var donationsListener: ListenerRegistration? = null

    private val ngoId: String
        get() = FirebaseAuth.getInstance().currentUser?.uid ?: DEMO_NGO_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNgoHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository.getUser(ngoId) { user ->
            binding.ngoName.text = user?.name ?: "NGO"
        }

        adapter = NgoDonationAdapter(emptyList()) { donation -> acceptDonation(donation.donationId) }
        binding.donationsRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.donationsRecyclerView.adapter = adapter

        binding.signOutLink.setOnClickListener {
            FirebaseAuth.getInstance().signOut()
            startActivity(Intent(this, com.ngoconnect.fooddonation.auth.LoginActivity::class.java))
            finish()
        }
    }

    override fun onStart() {
        super.onStart()
        donationsListener = repository.listenToNgoMatchedDonations(ngoId) { donations ->
            adapter.submitList(donations)
            binding.emptyState.visibility = if (donations.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    override fun onStop() {
        super.onStop()
        donationsListener?.remove()
        donationsListener = null
    }

    private fun acceptDonation(donationId: String) {
        repository.updateDonationStatus(donationId, DonationStatus.PICKUP_SCHEDULED) { success ->
            val message = if (success) getString(R.string.donation_accepted) else getString(R.string.error_generic)
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        private const val DEMO_NGO_ID = "demo-ngo"
    }
}
