package com.ngoconnect.fooddonation.donor

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.ngoconnect.fooddonation.databinding.ItemDonationBinding
import com.ngoconnect.fooddonation.model.Donation
import com.ngoconnect.fooddonation.model.DonationStatus

class DonationAdapter(
    private var items: List<Donation>,
    private val onClick: (Donation) -> Unit
) : RecyclerView.Adapter<DonationAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemDonationBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemDonationBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val donation = items[position]
        with(holder.binding) {
            foodType.text = donation.foodType
            quantity.text = donation.quantity
            pickupInfo.text = "${donation.pickupDate}, ${donation.pickupTime} · ${donation.pickupLocation}"
            statusPill.text = donation.status.label.uppercase()
            statusPill.setBackgroundResource(statusPillBackground(donation.status))

            distanceOrNgo.text = donation.ngoName?.let { "Matched with $it" } ?: "Waiting for an NGO to accept"

            root.setOnClickListener { onClick(donation) }
        }
    }

    override fun getItemCount(): Int = items.size

    fun submitList(newItems: List<Donation>) {
        items = newItems
        notifyDataSetChanged()
    }

    companion object {
        fun statusPillBackground(status: DonationStatus): Int {
            return when (status) {
                DonationStatus.LISTED -> com.ngoconnect.fooddonation.R.drawable.bg_pill_listed
                DonationStatus.NGO_FOUND -> com.ngoconnect.fooddonation.R.drawable.bg_pill_matched
                DonationStatus.PICKUP_SCHEDULED -> com.ngoconnect.fooddonation.R.drawable.bg_pill_scheduled
                DonationStatus.COMPLETED -> com.ngoconnect.fooddonation.R.drawable.bg_pill_completed
            }
        }
    }
}