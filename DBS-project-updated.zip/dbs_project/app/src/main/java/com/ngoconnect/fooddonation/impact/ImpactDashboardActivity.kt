package com.ngoconnect.fooddonation.impact

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityImpactDashboardBinding

/**
 * Impact Dashboard Module (Module 7): community-wide totals pulled from
 * completed donations across the whole platform (not just this donor).
 */
class ImpactDashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityImpactDashboardBinding
    private val repository = FirebaseRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImpactDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        repository.getImpactStats { mealsShared, successfulPickups, ngosServed ->
            binding.foodSavedValue.text = mealsShared.toString()
            binding.successfulPickupsValue.text = successfulPickups.toString()
            binding.ngosServedValue.text = ngosServed.toString()
        }
    }
}
