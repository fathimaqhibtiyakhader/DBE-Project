package com.ngoconnect.fooddonation.donor

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityCreateDonationBinding
import com.ngoconnect.fooddonation.geo.GeoMatchingRepository
import com.ngoconnect.fooddonation.geo.LocationHelper
import com.ngoconnect.fooddonation.model.Donation
import java.util.Calendar

/**
 * Screen: Create Donation (Donor Listing Module, Module 1).
 *
 * On submit: writes the Donation to Firestore, then hands off to the Geo
 * Matching module (Module 3) to find + assign the nearest verified NGO
 * using the donor's current device location.
 */
class CreateDonationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCreateDonationBinding
    private val repository = FirebaseRepository()
    private val geoMatchingRepository = GeoMatchingRepository(repository)
    private val calendar = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCreateDonationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.pickupDateInput.setOnClickListener { showDatePicker() }
        binding.pickupTimeInput.setOnClickListener { showTimePicker() }
        binding.submitButton.setOnClickListener { submitDonation() }
    }

    private fun showDatePicker() {
        DatePickerDialog(
            this,
            { _, year, month, day ->
                calendar.set(Calendar.YEAR, year)
                calendar.set(Calendar.MONTH, month)
                calendar.set(Calendar.DAY_OF_MONTH, day)
                binding.pickupDateInput.setText(String.format("%02d/%02d/%04d", day, month + 1, year))
            },
            calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun showTimePicker() {
        TimePickerDialog(
            this,
            { _, hour, minute ->
                binding.pickupTimeInput.setText(String.format("%02d:%02d", hour, minute))
            },
            calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), false
        ).show()
    }

    private fun submitDonation() {
        val foodType = binding.foodTypeInput.text?.toString()?.trim().orEmpty()
        val quantity = binding.quantityInput.text?.toString()?.trim().orEmpty()
        val date = binding.pickupDateInput.text?.toString()?.trim().orEmpty()
        val time = binding.pickupTimeInput.text?.toString()?.trim().orEmpty()
        val location = binding.pickupLocationInput.text?.toString()?.trim().orEmpty()
        val description = binding.descriptionInput.text?.toString()?.trim().orEmpty()

        if (foodType.isBlank() || quantity.isBlank() || date.isBlank() || time.isBlank() || location.isBlank()) {
            Toast.makeText(this, "Please fill in food type, quantity, pickup date/time and location", Toast.LENGTH_SHORT).show()
            return
        }

        val donorId = FirebaseAuth.getInstance().currentUser?.uid ?: DonorHomeActivity.DEMO_DONOR_ID
        setLoading(true)

        val donation = Donation(
            donorId = donorId,
            foodType = foodType,
            quantity = quantity,
            pickupDate = date,
            pickupTime = time,
            pickupLocation = location,
            description = description
        )

        repository.createDonation(donation) { donationId ->
            if (donationId == null) {
                setLoading(false)
                Toast.makeText(this, "Couldn't save the donation. Try again.", Toast.LENGTH_SHORT).show()
                return@createDonation
            }
            findNearestNgoAndFinish(donationId)
        }
    }

    /** Module 3 handoff: locate the donor, then match + assign the nearest verified NGO. */
    private fun findNearestNgoAndFinish(donationId: String) {
        LocationHelper.getCurrentLocation(
            context = this,
            onResult = { lat, lng ->
                geoMatchingRepository.matchDonationToNearestNgo(donationId, lat, lng) { match ->
                    setLoading(false)
                    val message = if (match != null) {
                        "Listed! Matched with ${match.ngo.name} (~${"%.1f".format(match.distanceKm)} km away)."
                    } else {
                        "Listed! No verified NGO nearby yet -- we'll match one as soon as there is."
                    }
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                    finish()
                }
            },
            onFailure = {
                // No location permission/fix -- the donation is still saved as LISTED;
                // it just won't have an NGO match until location is available.
                setLoading(false)
                Toast.makeText(this, "Listed! Enable location permission so we can match an NGO.", Toast.LENGTH_LONG).show()
                finish()
            }
        )
    }

    private fun setLoading(loading: Boolean) {
        binding.submitButton.isEnabled = !loading
        binding.submitProgress.visibility = if (loading) View.VISIBLE else View.GONE
    }
}
