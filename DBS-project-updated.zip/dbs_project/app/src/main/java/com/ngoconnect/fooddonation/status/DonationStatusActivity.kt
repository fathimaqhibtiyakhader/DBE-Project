package com.ngoconnect.fooddonation.status

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.ngoconnect.fooddonation.data.FirebaseRepository
import com.ngoconnect.fooddonation.databinding.ActivityDonationStatusBinding
import com.ngoconnect.fooddonation.donor.DonationAdapter

/** Screen: tap a donation card to see its full detail + current status. */
class DonationStatusActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDonationStatusBinding
    private val repository = FirebaseRepository()

    companion object {
        const val EXTRA_DONATION_ID = "extra_donation_id"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDonationStatusBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val donationId = intent.getStringExtra(EXTRA_DONATION_ID) ?: return
        repository.getDonation(donationId) { donation ->
            if (donation == null) return@getDonation
            binding.foodType.text = donation.foodType
            binding.quantity.text = donation.quantity
            binding.pickupInfo.text = "Pickup: ${donation.pickupDate}, ${donation.pickupTime} at ${donation.pickupLocation}"
            binding.description.text = donation.description
            binding.description.visibility = if (donation.description.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            binding.statusPill.text = donation.status.label.uppercase()
            binding.statusPill.setBackgroundResource(DonationAdapter.statusPillBackground(donation.status))

            val ngoName = donation.ngoName
            if (ngoName != null) {
                binding.ngoInfo.text = "Matched with $ngoName · %.1f km away".format(donation.distanceKm)
                binding.ngoInfo.visibility = android.view.View.VISIBLE
            } else {
                binding.ngoInfo.visibility = android.view.View.GONE
            }
        }
    }
}
